const FormHandlers = {
    wakeUpTime: 'WAKE_UP_TIME',
    sleepTime: 'SLEEP_TIME',
    weight: 'WEIGHT'
}

export default FormHandlers;